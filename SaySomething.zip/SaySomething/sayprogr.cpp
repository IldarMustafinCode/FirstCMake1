#include <iostream>
#include <Eigen/Core>
#include <Eigen/Dense>

int mainSayProgr()
{
    char something;
    std::cout << "Input something: ";
    std::cin >> something;
    std::cout << "Input weight: ";
    std::cin >> something;
    std::cout << "your word: " << something << std::endl;

    // // сумма элементов массива
    // Eigen::VectorXi v = Eigen::VectorXi::Random(10);
    // for (auto x : v)
    //     std::cout << x << " ";
    // std::cout << "\n";
    
}