#include <iostream>

// #include <gtest/gtest.h>


// TEST()
// {
// 	 GTEST_ASSERT_TRUE(my_sin(0.0), 0.0, eps);
// 	 my_sin(pi) == 0.0;
// 	 my_sin(0.1) == std::sin(0.1);
// }

// class Foo
// {
// 	Foo(int){}
// 	int p;
// };

int main()
{
	// int a;
	// {
	// 	int b;
	// }
	// {
	// 	double c;
	// 	Foo foo{1};
	// 	Foo* fo2 = new Foo{4};
	// 	delete fo2;
	// 	std::unique_ptr<Foo> fo3{4};
		
	// }
	std::cout << "Hello World" << std::endl;
	return 0;
}